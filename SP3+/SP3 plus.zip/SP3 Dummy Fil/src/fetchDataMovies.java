import java.sql.*;

public class fetchDataMovies {

        public static void connectToAndQueryDatabase(String username, String password) throws SQLException, ClassNotFoundException {
            //Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sp3plus", "root", "martin123");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT iD, MovieName, MovieYear, MovieCategory, Rating FROM MovieList");

            while (rs.next()) {
                int id = rs.getInt("iD");
                String mn = rs.getString("MovieName");
                String my = rs.getString("MovieYear");
                String mc = rs.getString("MovieCategory");
                String r = rs.getString("Rating");

                System.out.println(id +" "+mn +" "+my +" "+mc +" "+r);
            }
        }
    }


