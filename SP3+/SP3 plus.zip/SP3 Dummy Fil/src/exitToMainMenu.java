import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class exitToMainMenu {
    public static void main() throws IOException, SQLException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        System.out.println("If you want to exit to the main menu press y");
        String movieExit = sc.nextLine();
        if ("y".equals(movieExit)) {
            MainMenu.createMainMenu();
        }
    }
}
