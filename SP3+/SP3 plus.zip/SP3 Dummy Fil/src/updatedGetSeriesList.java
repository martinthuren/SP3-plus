import java.sql.*;
import java.util.Scanner;

public class updatedGetSeriesList {

        public static void main() throws SQLException, ClassNotFoundException {

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sp3plus?autoReconnect=true&useSSL=false", "root", "martin123");

            Scanner sc = new Scanner(System.in);
            String userinput = sc.nextLine();
            switch (userinput) {
                case "series" -> {
                    System.out.println("Here is all the series available!" + "\n" + "To choose a series you want to watch type the id number of the movie");
                    fetchDataSeries.connectToAndQueryDatabase("root", "martin123");
                    System.out.println("\n" + "You can also sort the series between" + "\n" + "Series name" + "\n" + "Series category" + "\n" + "Series year" + "\n" + "Series rating");
                    System.out.println("To do that type Series name, Series category, Series year, rating etc");
                    String userinput2 = sc.nextLine();
                    switch (userinput2) {
                        case "Series name" -> {
                            System.out.println("Type the name of the series you want to see");
                            String x = sc.nextLine();

                            String searchbyName = "SELECT * FROM SeriesList WHERE SeriesName LIKE " + "'" + x + "'";
                            PreparedStatement myStmt = con.prepareStatement(searchbyName);

                            System.out.println("Searching for movie...");

                            ResultSet resultSet = myStmt.executeQuery("SELECT * FROM SeriesList WHERE SeriesName LIKE " + "'" + x + "'");
                            ResultSetMetaData rsmd = resultSet.getMetaData();
                            int columnsNumber = rsmd.getColumnCount();
                            while (resultSet.next()) {
                                for (int i = 1; i <= columnsNumber; i++) {
                                    if (i > 1) System.out.print(",  ");
                                    String columnValue = resultSet.getString(i);
                                    System.out.print(columnValue + " " + rsmd.getColumnName(i));
                                }
                                System.out.println("");
                                try {
                                    exitToMainMenu.main();
                                } catch (Exception ex) {
                                    System.out.println("Internal error");

                                }
                            }
                        }
                    }
                }
            }
        }
    }

