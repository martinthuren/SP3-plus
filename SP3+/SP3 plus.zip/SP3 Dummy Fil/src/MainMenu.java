import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class MainMenu extends AccountStart {
    public static void createMainMenu() throws IOException, SQLException, ClassNotFoundException {
        Scanner use = new Scanner(System.in);
        System.out.println("****************************************");
        System.out.println("Here is your following options to choose from");
        System.out.println("1. Choose between all movies");       //vis alle film //underkategori spil den valgte film //gem filmen knap
        System.out.println("2. Choose between all series"); //liste af sete film
        System.out.println("3. List of watched movies"); //liste af sete film
        System.out.println("4. List of saved movies");   //liste af gemte film
        System.out.println("5. Exit");                   //gå ud af programmet
        System.out.println("****************************************");
        String userChoice = use.nextLine();
        switch (userChoice) {
            case "1":
                updatedGetMovieList.main();
                break;
            case "2":
                updatedGetSeriesList.main();
                break;
            case "3":
                System.out.println("List of watched movies");
                break;
            case "4":
                System.out.println("List of saved movies");
                break;
            case "5":
                System.out.println("You are exiting StreamFix");
                break;
        }
    }
}
