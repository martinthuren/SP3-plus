import java.util.Scanner;

public class AccountStart {
    public static void startMenu() {

        System.out.println("Welcome to StreamFix!" + "\n" + "Do you want to login or create account?" + "\n" + "Type l to login or c to create account");
        Scanner s = new Scanner(System.in);
        String userChoice = s.nextLine();
        switch (userChoice) {
            case "l":
                System.out.println("Enter your username: " + "\n");
                s.nextLine();
                System.out.println("Enter your password: ");
                s.nextLine();
                System.out.println("****************************************");
                System.out.println("Your account has succesfully been logged into!" + "\n" + "Press Y followed by enter to continue");
                System.out.println("****************************************");
               String d = s.nextLine();
               if (d.equalsIgnoreCase("y")) {
                   break;
               }

            case "c":
                System.out.println("Enter your desired username: " + "\n");
                s.nextLine();
                System.out.println("Enter your desired password: ");
                s.nextLine();
                System.out.println("****************************************");
                System.out.println("Your account has succesfully been created!" + "\n" + "Press Y followed by enter to continue");
                System.out.println("****************************************");
                String k = s.nextLine();
                if (k.equalsIgnoreCase("y")) {
                    break;
        }
        }
    }
}
