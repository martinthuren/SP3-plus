import java.sql.*;

public class fetchDataSeries {

    public static void connectToAndQueryDatabase(String username, String password) throws SQLException, ClassNotFoundException {
        //Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sp3plus", "root", "martin123");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT iD, SeriesName, SeriesYear, SeriesCategory, SeriesRating, SeriesSeasons FROM SeriesList");

        while (rs.next()) {
            int id = rs.getInt("iD");
            String mn = rs.getString("SeriesName");
            String my = rs.getString("SeriesYear");
            String mc = rs.getString("SeriesCategory");
            String sr = rs.getString("SeriesRating");
            String ss = rs.getString("SeriesSeasons");

            System.out.println(id +" "+mn +" "+my +" "+mc +" "+sr+" "+ss);
        }
    }
}


