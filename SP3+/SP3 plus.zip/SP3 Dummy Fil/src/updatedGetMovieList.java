import java.sql.*;
import java.util.Scanner;

public class updatedGetMovieList {
    public static void main() throws SQLException, ClassNotFoundException {

        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sp3plus?autoReconnect=true&useSSL=false", "root", "martin123");

        Scanner sc = new Scanner(System.in);
        System.out.println("Here is all the movies available!" + "\n" + "To choose a movie you want to watch type the id number of the movie");
        fetchDataMovies.connectToAndQueryDatabase("root", "martin123");
        System.out.println("\n" + "You can also sort the movies between" + "\n" + "Movie name" + "\n" + "Movie category" + "\n" + "Movie year" + "\n" + "Rating");
        System.out.println("To do that type Movie name, Movie category, Movie year, Rating etc");
        String userinput = sc.nextLine();

        switch (userinput) {
            case "Movie name" -> {
                System.out.println("Type the name of the movie you want to see");

                String x = sc.nextLine();
                String searchbyName = "SELECT * FROM MovieList WHERE MovieName LIKE " + "'" + x + "'";
                PreparedStatement myStmt = con.prepareStatement(searchbyName);

                System.out.println("Searching for movie...");

                ResultSet resultSet = myStmt.executeQuery("SELECT * FROM MovieList WHERE MovieName LIKE " + "'" + x + "'");
                ResultSetMetaData rsmd = resultSet.getMetaData();
                int columnsNumber = rsmd.getColumnCount();
                while (resultSet.next()) {
                    for (int i = 1; i <= columnsNumber; i++) {
                        if (i > 1) System.out.print(",  ");
                        String columnValue = resultSet.getString(i);
                        System.out.print(columnValue + " " + rsmd.getColumnName(i));
                    }
                    System.out.println("");

                    try {
                        exitToMainMenu.main();
                    } catch (Exception ex) {
                        System.out.println("Internal error");


                    }
                }
            }
            case "Movie category" -> {
                System.out.println("Type the category of the movie you want to see");

                String x = sc.nextLine();
                String searchbyName = "SELECT * FROM MovieList WHERE MovieCategory LIKE " + "'" + x + "'";
                PreparedStatement myStmt = con.prepareStatement(searchbyName);

                System.out.println("Searching for movie...");

                ResultSet resultSet = myStmt.executeQuery("SELECT * FROM MovieList WHERE MovieCategory LIKE " + "'" + x + "'");
                ResultSetMetaData rsmd = resultSet.getMetaData();
                int columnsNumber = rsmd.getColumnCount();
                while (resultSet.next()) {
                    for (int i = 1; i <= columnsNumber; i++) {
                        if (i > 1) System.out.print(",  ");
                        String columnValue = resultSet.getString(i);
                        System.out.print(columnValue + " " + rsmd.getColumnName(i));
                    }
                    System.out.println("");
                    try {
                        exitToMainMenu.main();
                    } catch (Exception ex) {
                        System.out.println("Internal error");

                    }
                }
            }
            case "Movie year" -> {
                System.out.println("Type the year of the movie you want to see");

                String x = sc.nextLine();
                String searchbyName = "SELECT * FROM MovieList WHERE MovieYear LIKE " + "'" + x + "'";
                PreparedStatement myStmt = con.prepareStatement(searchbyName);

                System.out.println("Searching for movie...");

                ResultSet resultSet = myStmt.executeQuery("SELECT * FROM MovieList WHERE MovieYear LIKE " + "'" + x + "'");
                ResultSetMetaData rsmd = resultSet.getMetaData();
                int columnsNumber = rsmd.getColumnCount();
                while (resultSet.next()) {
                    for (int i = 1; i <= columnsNumber; i++) {
                        if (i > 1) System.out.print(",  ");
                        String columnValue = resultSet.getString(i);
                        System.out.print(columnValue + " " + rsmd.getColumnName(i));
                    }
                    System.out.println("");
                    try {
                        exitToMainMenu.main();
                    } catch (Exception ex) {
                        System.out.println("Internal error");
                    }
                }
            }
            case "Rating" -> {
                System.out.println("Type the rating of the movie you want to see");

                String x = sc.nextLine();
                String searchbyName = "SELECT * FROM MovieList WHERE Rating LIKE " + "'" + x + "'";
                PreparedStatement myStmt = con.prepareStatement(searchbyName);

                System.out.println("Searching for movie...");

                ResultSet resultSet = myStmt.executeQuery("SELECT * FROM MovieList WHERE Rating LIKE " + "'" + x + "'");
                ResultSetMetaData rsmd = resultSet.getMetaData();
                int columnsNumber = rsmd.getColumnCount();
                while (resultSet.next()) {
                    for (int i = 1; i <= columnsNumber; i++) {
                        if (i > 1) System.out.print(",  ");
                        String columnValue = resultSet.getString(i);
                        System.out.print(columnValue + " " + rsmd.getColumnName(i));
                    }
                    System.out.println("");
                    try {
                        exitToMainMenu.main();
                    } catch (Exception ex) {
                        System.out.println("Internal error");
                    }
                }
            }
        }
    }
}